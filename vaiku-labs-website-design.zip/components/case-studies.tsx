"use client"

import { Play } from "lucide-react"
import { useState, useEffect } from "react"

export default function CaseStudies() {
  const [hoveredCase, setHoveredCase] = useState<number | null>(null)
  const [visibleItems, setVisibleItems] = useState<number[]>([])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number(entry.target.getAttribute("data-index"))
            setVisibleItems((prev) => [...new Set([...prev, index])])
          }
        })
      },
      { threshold: 0.1 },
    )

    document.querySelectorAll("[data-case-item]").forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  const cases = [
    {
      id: 1,
      title: "Enterprise AI Transformation",
      subtitle: "Fortune 500 Financial Services",
      problem: "Processing millions of documents manually",
      solution: "Custom NLP pipeline with real-time extraction",
      impact: "85% reduction in processing time",
    },
    {
      id: 2,
      title: "Cloud Migration Initiative",
      subtitle: "Global Manufacturing Company",
      problem: "Legacy infrastructure limiting scalability",
      solution: "Complete cloud-native architecture redesign",
      impact: "3x increase in system capacity",
    },
    {
      id: 3,
      title: "Workflow Automation",
      subtitle: "Healthcare Organization",
      problem: "Manual patient data entry consuming 40% of staff time",
      solution: "End-to-end RPA implementation with AI validation",
      impact: "95% automation success rate",
    },
    {
      id: 4,
      title: "Predictive Analytics Platform",
      subtitle: "E-commerce Marketplace",
      problem: "Inability to predict customer churn",
      solution: "Machine learning models for behavior prediction",
      impact: "40% improvement in retention",
    },
  ]

  return (
    <section id="cases" className="py-16 md:py-32 bg-primary/5">
      <div className="max-w-7xl mx-auto px-4 md:px-12">
        <div className="text-center space-y-3 md:space-y-4 mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground">Case Studies</h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto px-4">
            Real solutions delivering measurable impact for our partners
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 md:gap-6">
          {cases.map((caseStudy, index) => {
            const isVisible = visibleItems.includes(caseStudy.id - 1)
            return (
              <div
                key={caseStudy.id}
                data-case-item
                data-index={caseStudy.id - 1}
                className={`relative group rounded-xl md:rounded-2xl overflow-hidden bg-card border border-border hover:border-primary transition-all duration-300 ${
                  isVisible ? "animate-fade-in-up" : "opacity-0"
                }`}
                onMouseEnter={() => setHoveredCase(caseStudy.id)}
                onMouseLeave={() => setHoveredCase(null)}
                style={{ animationDelay: `${(caseStudy.id - 1) * 100}ms` }}
              >
                {/* Background gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10" />

                {/* Content */}
                <div className="relative p-5 md:p-8 space-y-4">
                  <div>
                    <h3 className="text-base md:text-xl font-bold text-foreground">{caseStudy.title}</h3>
                    <p className="text-xs md:text-sm text-muted-foreground">{caseStudy.subtitle}</p>
                  </div>

                  <div className="space-y-2 md:space-y-3 pt-3 md:pt-4 border-t border-border">
                    <div>
                      <p className="text-xs font-semibold text-primary uppercase tracking-wide">Problem</p>
                      <p className="text-xs md:text-sm text-foreground mt-1">{caseStudy.problem}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-accent uppercase tracking-wide">Solution</p>
                      <p className="text-xs md:text-sm text-foreground mt-1">{caseStudy.solution}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-secondary uppercase tracking-wide">Impact</p>
                      <p className="text-xs md:text-sm text-foreground font-semibold mt-1">{caseStudy.impact}</p>
                    </div>
                  </div>

                  {/* Watch video button - appears on hover */}
                  {hoveredCase === caseStudy.id && (
                    <button className="mt-4 md:mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white hover:bg-primary/90 transition-colors text-xs md:text-sm font-semibold animate-scale-in">
                      <Play size={16} />
                      Watch Video
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
