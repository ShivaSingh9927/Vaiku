"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Hero() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navLinks = [
    { label: "Services", href: "#services" },
    { label: "Case Studies", href: "#cases" },
    { label: "About", href: "#about" },
    { label: "Contact", href: "#contact" },
  ]

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-primary to-primary/80 text-white overflow-hidden">
      {/* Animated background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 right-20 w-72 h-72 md:w-96 md:h-96 bg-secondary rounded-full blur-3xl animate-float" />
        <div
          className="absolute bottom-20 left-20 w-64 h-64 md:w-80 md:h-80 bg-accent rounded-full blur-3xl animate-float"
          style={{ animationDelay: "2s" }}
        />
      </div>

      {/* Navigation */}
      <nav className="relative z-50 flex items-center justify-between px-4 md:px-12 py-4 md:py-6">
        <div className="flex items-center gap-2">
          <div className="w-8 md:w-10 h-8 md:h-10 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0">
            <span className="text-primary font-bold text-sm md:text-lg">V</span>
          </div>
          <span className="font-bold text-sm md:text-xl">VAIKU LABS</span>
        </div>

        {/* Desktop menu */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium hover:text-secondary transition-colors duration-300"
            >
              {link.label}
            </Link>
          ))}
        </div>

        <div className="hidden md:flex gap-4">
          <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
            Get in Touch
          </Button>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-primary/95 backdrop-blur-sm z-40 p-4 space-y-3 animate-fade-in-up">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="block text-white hover:text-secondary transition-colors py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <Button className="w-full bg-secondary hover:bg-secondary/90 text-primary">Get in Touch</Button>
        </div>
      )}

      {/* Hero content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-12 py-16 md:py-32 flex flex-col lg:flex-row items-center justify-between gap-8 md:gap-12">
        <div className="flex-1 space-y-4 md:space-y-6 animate-slide-in-left w-full">
          <div className="inline-block px-3 md:px-4 py-2 rounded-full bg-white/10 border border-white/20 text-xs md:text-sm font-medium w-fit">
            Transforming Business Through Intelligence
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight text-balance">
            Intelligent Solutions. <span className="text-secondary">Empowered Futures.</span>
          </h1>

          <p className="text-base md:text-lg text-white/80 max-w-2xl">
            We build scalable AI & software solutions that transform businesses. From enterprise automation to custom
            intelligence systems, we deliver results that matter.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 pt-4">
            <Button className="bg-secondary hover:bg-secondary/90 text-primary font-semibold px-6 md:px-8 py-5 md:py-6 text-sm md:text-base w-full sm:w-auto">
              Explore Services
            </Button>
            <Button
              variant="outline"
              className="bg-transparent border-white text-white hover:bg-white/10 font-semibold px-6 md:px-8 py-5 md:py-6 text-sm md:text-base w-full sm:w-auto"
            >
              Get a Consultation
            </Button>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 md:gap-8 pt-6 md:pt-8 text-xs md:text-sm">
            <div>
              <div className="font-bold text-xl md:text-2xl text-secondary">25+</div>
              <div className="text-white/70">AI Products Delivered</div>
            </div>
            <div>
              <div className="font-bold text-xl md:text-2xl text-secondary">100%</div>
              <div className="text-white/70">Client Retention</div>
            </div>
          </div>
        </div>

        {/* Hero visual - hidden on mobile, shown on md and up */}
        <div className="flex-1 hidden lg:block w-full animate-slide-in-right">
          <div className="relative w-full aspect-square">
            <div className="absolute inset-0 bg-gradient-to-br from-secondary/30 to-accent/30 rounded-2xl md:rounded-3xl blur-2xl" />
            <div className="relative bg-white/5 backdrop-blur-sm rounded-2xl md:rounded-3xl p-6 md:p-8 border border-white/10">
              <div className="space-y-3 md:space-y-4">
                <div className="h-48 md:h-64 bg-gradient-to-br from-secondary/40 to-accent/40 rounded-xl md:rounded-2xl" />
                <div className="grid grid-cols-2 gap-2 md:gap-3">
                  <div className="h-16 md:h-20 bg-secondary/30 rounded-lg" />
                  <div className="h-16 md:h-20 bg-accent/30 rounded-lg" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
